+-------------------------------------------------------------------------+
| "CV Gris" Twitter Bootstrap Theme                  	         |
| Revision: 1.1 24.02.2013         	                                     |
+-------------------------------------------------------------------------+
| Copyright (C) 2013 Yevgeny Simzikov		         |
+-------------------------------------------------------------------------+

	FILE LICENSES

1.  Icons by FontAwesome
	
	Designer: Dave Gandy
	License: SIL Open Font License - http://scripts.sil.org/OFL
	URL: http://fortawesome.github.com/Font-Awesome/
		 
2. 	assets/img/bg.jpg
 	assets/img/bg-top.jpg
 	assets/img/avatar.jpg
	
	Designer: Yevgeny Simzikov (the author of this item)
	License: Free for commercial use
	
3.  Bootstrap Calendar snippet

	Designer: Pyrou
	License: http://bootsnipp.com/license
	URL: http://bootsnipp.com/snipps/better-one-month-calendar